% Multi-class Classification, task manager for TAv2 task manager code 

% Input structures

% Output structures

% REQUIRESTMENT: Matlab
% Copyright(c)2020 Attila Korik, http://isrc.ulster.ac.uk/akorik/contact.html


%% VA Setup (A1 prep)

clear; clc;

cf_T1_TAv2_TM
% addpath(genpath([V1_TRANS.f.HomeDir,'\Code\Toolboxes for FBCSP\Toolbox (used elements)']));
addpath(genpath([V1_TRANS.f.HomeDir,'\Code\Toolboxes for FBCSP\add to path']));


%% TaskManager code for TAv2 task manager code 

% ______________________________
% 
% Identify Source data structure
% ______________________________

dir0 = V1_TRANS.f.SourceDataDir;
dir0_struct = dir(dir0);
wm_fileID = 0;
for wm1 = 1 : size(dir0_struct,1)
  if dir0_struct(wm1,1).isdir == 1    % if directory
    if sum(ismember(dir0_struct(wm1,1).name,'.')) == 0  % if the name not involves '.'
      
      subDir1 = dir0_struct(wm1,1).name;
      dir1 = [dir0, '\', subDir1];
      dir1_struct = dir(dir1);
      for wm2 = 1 : size(dir1_struct,1)
        if dir1_struct(wm2,1).isdir == 1    % if directory
          if sum(ismember(dir1_struct(wm2,1).name,'.')) == 0  % if the name not involves '.'
            
            subDir2 = dir1_struct(wm2,1).name;
            dir2 = [dir1, '\', subDir2];
            dir2_struct = dir(dir2);
            for wm3 = 1 : size(dir2_struct,1)
              if strcmp(dir2_struct(wm3,1).name,V1_TRANS.f.SourceDataName)
                wm_fileID = wm_fileID +1;
                tr_file_list{wm_fileID} = [dir2, '\', V1_TRANS.f.SourceDataName];
                  tr_subDir_list{wm_fileID} = [subDir1, '\', subDir2];     % this info also involved in tr_file_list{wm_fileID} 
              end
            end
            
          end
        end
      end
        
    end
  end
end
V1_TRANS.tr_file_list = tr_file_list;
V1_TRANS.tr_subDir_list = tr_subDir_list;
clearvars -except V1_TRANS

% ____________________________________________________________________________________________________________________
% 
% Identify previously processed result structure + remove already processed options from list of data be processed now 
% ____________________________________________________________________________________________________________________

if ~isempty(V1_TRANS.f.PreviousResultDir)
 tr_file_list = V1_TRANS.tr_file_list;
 tr_subDir_list = V1_TRANS.tr_subDir_list;
 
 dir0 = V1_TRANS.f.PreviousResultDir;
 dir0_struct = dir(dir0);
 wm_fileID = 0;
 for wm1 = 1 : size(dir0_struct,1)
  if dir0_struct(wm1,1).isdir == 1    % if directory
    if sum(ismember(dir0_struct(wm1,1).name,'.')) == 0  % if the name not involves '.'
      
      subDir1 = dir0_struct(wm1,1).name;
      dir1 = [dir0, '\', subDir1];
      dir1_struct = dir(dir1);
      for wm2 = 1 : size(dir1_struct,1)
        if dir1_struct(wm2,1).isdir == 1    % if directory
          if sum(ismember(dir1_struct(wm2,1).name,'.')) == 0  % if the name not involves '.'
            
            subDir2 = dir1_struct(wm2,1).name;

            wm = find(ismember(tr_subDir_list, [subDir1,'\',subDir2]));
            if ~isempty(wm)
             if size(tr_file_list,2) == 1
              fprintf('All data has already been analysed\n');
              tr_file_list = '';
              tr_subDir_list = '';
             else
              if wm ~= 1
                for wm3 = 1 : wm-1
                  tmp.tr_file_list{wm3} = tr_file_list{wm3};
                  tmp.tr_subDir_list{wm3} = tr_subDir_list{wm3};
                end
              end
              if wm ~= size(tr_file_list,2)
                for wm3 = wm+1 : size(tr_file_list,2)
                  tmp.tr_file_list{wm3-1} = tr_file_list{wm3};
                  tmp.tr_subDir_list{wm3-1} = tr_subDir_list{wm3};
 
            end
              end
              tr_file_list = tmp.tr_file_list;
              tr_subDir_list = tmp.tr_subDir_list;
              clearvars tmp
             end
            end
            
          end
        end
      end
        
    end
  end
 end
 V1_TRANS.tr_file_list = tr_file_list;
 V1_TRANS.tr_subDir_list = tr_subDir_list;
 clearvars -except V1_TRANS
end

% ____________
% 
% Task Manager
% ____________

if isempty(V1_TRANS.processed_taskIDs)
  V1_TRANS.processed_taskIDs = 1 : size(V1_TRANS.tr_file_list,2);
end

tr_file_list = V1_TRANS.tr_file_list;
tr_subDir_list = V1_TRANS.tr_subDir_list;
for wm_taskID = 1 : size(tr_file_list,2)
 V1_TRANS.wm_taskID = wm_taskID;
 
 if sum(ismember(V1_TRANS.processed_taskIDs,wm_taskID))==0
   if ~exist('T1_result_table')
     TA_addEmpty_to_resultSummary
%      T1_result_table = '';
   elseif size(T1_result_table,1) < wm_taskID
     TA_addEmpty_to_resultSummary
   end
 else
 
% %  wm = strfind(tr_file_list{wm_taskID},'\');
% %  % if ~contains(lower(tr_file_list{wm_taskID}(1,wm(1,end-1)+1:wm(1,end)-1)), 'q')
% %  if contains(lower(tr_file_list{wm_taskID}(1,wm(1,end-1)+1:wm(1,end)-1)), 'q')
  
  % fprintf([tr_file_list{wm_taskID}, '\',V1_TRANS.f.SourceDataName,' (',num2str(wm_taskID),'/',num2str(size(tr_file_list,2)),') ...\n']);
  fprintf(['\n________________________\n\n']);
  fprintf(['Processing (#',num2str(wm_taskID),'/',num2str(size(tr_file_list,2)),') ...\n']);
  
  % copy chanlocs file
  % __________________
  
  % copyfile([VA_TRANS.f.chanlocs_path,VA_TRANS.f.chanlocs_filename], [VA_TRANS.f.baseDir,'\',VA_TRANS.f.chanlocs_filename]);
  % copyfile([V1_TRANS.f.chanlocs_dir,'\',V1_TRANS.f.chanlocs_filename], [V1_TRANS.f.BaseDir_for_trainTest,'\',V1_TRANS.f.chanlocs_filename]);
  copyfile([V1_TRANS.f.chanlocs_dir,'\',V1_TRANS.f.chanlocs_filename], [V1_TRANS.f.BaseDir,'\',V1_TRANS.f.chanlocs_filename]);

  % EEG_rec dataset tranfer (converted Source data to Work data )
  % _____________________________________________________________
  
  TA_Dataset_Transfer
  
  % Try trainTest task manager code
  % _______________________________
  
      % Stacking all variables into STACK(1)
      % ____________________________________
      
      STACK_allVariables_01
      % clearvars -except STACK 
        clearvars VA_TRANS
        VA_TRANS.SW_T1_maxTrainTestTry = V1_TRANS.SW.T1_maxTrainTestTry;
        VA_TRANS.subjID_text = V1_TRANS.tr_subDir_list{1,wm_taskID}(find(V1_TRANS.tr_subDir_list{1,wm_taskID}=='\')+1:end);
        clearvars -except STACK VA_TRANS
  
% %   % try
% %   %   VA_TRANS.T1_tryCounter = 1;
% %   %   TAv2_TrainTest
% %   %   wm_ok = 1;
% %   % catch
% %   %   wm_ok = 0;
% %   % end
% %   try
% %     VA_TRANS.T1_tryCounter = 1;
% %     TAv2_TrainTest
% %     wm_ok = 1;
% %   catch
% %     try
% %       VA_TRANS.T1_tryCounter = 2;
% %       TAv2_TrainTest
% %       wm_ok = 1;
% %     catch
% %       try
% %         VA_TRANS.T1_tryCounter = 1;
% %         TAv2_TrainTest
% %         wm_ok = 1;
% %       catch
% %         wm_ok = 0;
% %       end
% %     end
% %   end
  if VA_TRANS.SW_T1_maxTrainTestTry == 0
    VA_TRANS.T1_tryCounter = 1;
    TAv2_TrainTest
    wm_ok = 1;
  else
   try
    VA_TRANS.SW_T1_maxTrainTestTry = 1;
    TAv2_TrainTest
    wm_ok = 1;
   catch
    if VA_TRANS.SW_T1_maxTrainTestTry > 1
     try
      VA_TRANS.SW_T1_maxTrainTestTry = 2;
      TAv2_TrainTest
      wm_ok = 1;
     catch
      if VA_TRANS.SW_T1_maxTrainTestTry > 2
       try
        VA_TRANS.T1_tryCounter = 1;
        TAv2_TrainTest
        wm_ok = 1;
       catch
        wm_ok = 0;
       end
      end
     end
    end
   end
  end
  if wm_ok == 1
        % Restore variables from STACK
        % ____________________________
        % clearvars -except STACK VA_TRANS result
        % clearvars -except STACK VA_TRANS
        clearvars -except STACK
        STACK_restore_01
        
    % Add new line to results to summary
    % __________________________________
    TA_append_resultSummary
    
    % Copy important param and result files to the final T1 sub-directories
    % _____________________________________________________________________
    TA_copy_T1_files
    
    % Delete 'heatmap (Freq v4).fig'
    % ______________________________
    delete([V1_TRANS.f.BaseDir,'\T1\Results\',V1_TRANS.tr_subDir_list{wm_taskID},'\+ Fig\heatmap (Freq v4).fig']);
    
    % prepare online setup file
    % _________________________
    if ~isempty(V1_TRANS.f.T1_param_subSubDir)
      TC_Online_prep_func(V1_TRANS)
      TA_copy_T1_online_files
    end
  else
        % Restore variables from STACK
        % ____________________________
        % clearvars -except STACK VA_TRANS result
        % clearvars -except STACK VA_TRANS
        clearvars -except STACK
        STACK_restore_01
        
    % Add new line to results to summary
    % __________________________________
    TA_addEmpty_to_resultSummary
  end
  
  % Delete directories and files which used for TrainTest (important content already copied into the final (T1) directory)
  % ______________________________________________________________________________________________________________________
  if isdir([V1_TRANS.f.BaseDir,'\',V1_TRANS.f.T1_online_subSubDir])
    rmdir([V1_TRANS.f.BaseDir,'\',V1_TRANS.f.T1_online_subSubDir],'s');
  end
  if isdir([V1_TRANS.f.BaseDir,'\',V1_TRANS.f.DataSubDir])
    rmdir([V1_TRANS.f.BaseDir,'\',V1_TRANS.f.DataSubDir],'s');
  end
  if isdir([V1_TRANS.f.BaseDir,'\',V1_TRANS.f.TrainTestSubDir])
    rmdir([V1_TRANS.f.BaseDir,'\',V1_TRANS.f.TrainTestSubDir],'s');
  end
  delete([V1_TRANS.f.BaseDir,'\',V1_TRANS.f.chanlocs_filename]);
  
 end
end


%%

%{
% ______________________________
% 
% Delete 'heatmap (Freq v4).fig'
% ______________________________

tr_file_list = V1_TRANS.tr_file_list;
tr_subDir_list = V1_TRANS.tr_subDir_list;
for wm_taskID = 1 : size(tr_file_list,2)
  delete([V1_TRANS.f.BaseDir,'\T1\Results\',V1_TRANS.tr_subDir_list{wm_taskID},'\+ Fig\heatmap (Freq v4).fig']);
end
%}



%% Comments

%{
addpath('C:\BCI\DCR\191217 CL\Code\Toolbox (used elements)');
addpath('C:\BCI\DCR\191217 CL\Code\Toolbox (used elements)\from eeglab14_1_1b');
%}

%{
addpath('D:\Csc\DCR\W Toolbox (used elements) for FBCSP');
addpath('D:\Csc\DCR\W Toolbox (used elements) for FBCSP\from eeglab14_1_1b');
%}

%{
addpath('T:\Brain-Computer Interface\Csc\DCR\CL\Code');
addpath('T:\Brain-Computer Interface\Csc\DCR\CL\Code\W Toolbox (used elements) for FBCSP');
addpath('T:\Brain-Computer Interface\Csc\DCR\CL\Code\W Toolbox (used elements) for FBCSP\from eeglab14_1_1b');
%}

%{
addpath('\\sceis_cl1fs\shared\Brain-Computer Interface\Csc\DCR\CL\Code');
addpath('\\sceis_cl1fs\shared\Brain-Computer Interface\Csc\DCR\CL\Code\W Toolbox (used elements) for FBCSP');
addpath('\\sceis_cl1fs\shared\Brain-Computer Interface\Csc\DCR\CL\Code\W Toolbox (used elements) for FBCSP\from eeglab14_1_1b');
%}

%{
addpath('\\sceis_cl1fs\shared\Brain-Computer Interface\Csc\DCR\CL\Code2');
addpath('\\sceis_cl1fs\shared\Brain-Computer Interface\Csc\DCR\CL\Code2\W Toolbox (used elements) for FBCSP');
addpath('\\sceis_cl1fs\shared\Brain-Computer Interface\Csc\DCR\CL\Code2\W Toolbox (used elements) for FBCSP\from eeglab14_1_1b');
%}

%{
    delete(gcp('nocreate'))     % parpool close

%     w.parCore.location = 'local';
%     w.parCore.number = 4;
    w.parCore.location = 'HPCServerProfile1';
%     w.parCore.number = 8;
    w.parCore.number = 101;
    parpool (w.parCore.location, w.parCore.number)       % open cores
%}









